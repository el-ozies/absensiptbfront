import React from 'react';
import { useState, useEffect } from 'react';
import api from '../../api/axios';

const Absen = () => {
  const [latitude, setLatitude] = useState(null);
  const [longitude, setLongitude] = useState(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  // Dapatkan lokasi saat halaman dibuka
  useEffect(() => {
    if (!navigator.geolocation) {
      setMessage('Browser tidak mendukung geolocation.');
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLatitude(pos.coords.latitude);
        setLongitude(pos.coords.longitude);
      },
      () => {
        setMessage('Gagal mengambil lokasi. Aktifkan GPS atau izin lokasi.');
      }
    );
  }, []);

  const handleAbsen = async () => {
    if (!latitude || !longitude) {
      setMessage('Lokasi belum tersedia.');
      return;
    }

    setLoading(true);
    try {
      const res = await api.post('/absensi/masuk', {
        latitude,
        longitude,
        device_id: 'DEVICE001',
        foto_masuk: 'foto123.jpg' // opsional kalau upload
      });

      setMessage(res.data.message || 'Berhasil absen.');
    } catch (err) {
      setMessage(err.response?.data?.message || 'Gagal absen.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h2>Absensi Masuk</h2>
      <p>Latitude: {latitude}</p>
      <p>Longitude: {longitude}</p>
      <button onClick={handleAbsen} disabled={loading}>
        {loading ? 'Mengirim...' : 'Absen Sekarang'}
      </button>
      {message && <p>{message}</p>}
    </div>
  );
};

export default Absen;
