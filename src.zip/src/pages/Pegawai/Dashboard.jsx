import React from 'react';
import { useNavigate } from 'react-router-dom';

const DashboardPegawai = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '/';
  };

  return (
    <div>
      <h2>Dashboard Pegawai</h2>
      <p>Selamat datang di Sistem Absensi PTB</p>

      <button onClick={() => navigate('/pegawai/absen')}>Absen</button>
      <button onClick={() => navigate('/pegawai/riwayat')}>Riwayat</button>
      <button onClick={handleLogout}>Logout</button>
    </div>
  );
};

export default DashboardPegawai;
