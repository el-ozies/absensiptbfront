import React from 'react';
import { useEffect, useState } from 'react';
import api from '../../api/axios';

const Riwayat = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/absensi/riwayat')
      .then(res => setData(res.data))
      .catch(() => alert('Gagal memuat data'))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <h2>Riwayat Absensi</h2>
      {loading ? (
        <p>Memuat data...</p>
      ) : (
        <table border="1">
          <thead>
            <tr>
              <th>Tanggal</th>
              <th>Jam Masuk</th>
              <th>Jam Keluar</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {data.map((absen) => (
              <tr key={absen.id}>
                <td>{absen.tanggal}</td>
                <td>{absen.jam_masuk || '-'}</td>
                <td>{absen.jam_keluar || '-'}</td>
                <td>{absen.status || '-'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default Riwayat;
