import React from 'react';
import { useEffect, useState } from 'react';
import api from '../../api/axios';

const RekapAbsensi = () => {
  const [rekap, setRekap] = useState([]);
  const [tanggal, setTanggal] = useState('');
  const [loading, setLoading] = useState(false);

  const fetchRekap = async () => {
    setLoading(true);
    try {
      const response = await api.get('/absensi/rekap', {
        params: tanggal ? { tanggal } : {},
      });
      setRekap(response.data);
    } catch (err) {
      alert('Gagal mengambil data rekap');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRekap();
  }, []);

  const handleFilter = (e) => {
    e.preventDefault();
    fetchRekap();
  };

  return (
    <div>
      <h2>Rekap Absensi</h2>

      <form onSubmit={handleFilter}>
        <label>
          Filter Tanggal:
          <input
            type="date"
            value={tanggal}
            onChange={(e) => setTanggal(e.target.value)}
          />
        </label>
        <button type="submit">Terapkan</button>
        <button type="button" onClick={() => { setTanggal(''); fetchRekap(); }}>
          Reset
        </button>
      </form>

      {loading ? (
        <p>Memuat data...</p>
      ) : (
        <table border="1">
          <thead>
            <tr>
              <th>Tanggal</th>
              <th>Nama</th>
              <th>NIP</th>
              <th>Masuk</th>
              <th>Keluar</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {rekap.map((row) => (
              <tr key={row.id}>
                <td>{row.tanggal}</td>
                <td>{row.nama}</td>
                <td>{row.nip}</td>
                <td>{row.jam_masuk || '-'}</td>
                <td>{row.jam_keluar || '-'}</td>
                <td>{row.status || '-'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default RekapAbsensi;
