import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Login from '../pages/Login';
import DashboardPegawai from '../pages/Pegawai/Dashboard';
import Absen from '../pages/Pegawai/Absen';
import Riwayat from '../pages/Pegawai/Riwayat';
import DashboardAdmin from '../pages/Admin/Dashboard';
import RekapAbsensi from '../pages/Admin/RekapAbsensi';
import PrivateRoute from './PrivateRoute';
import Register from '../pages/Register';

const AppRoutes = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route
          path="/pegawai/dashboard"
          element={<PrivateRoute><DashboardPegawai /></PrivateRoute>}
        />
        <Route
          path="/pegawai/absen"
          element={<PrivateRoute><Absen /></PrivateRoute>}
        />
        <Route
          path="/pegawai/riwayat"
          element={<PrivateRoute><Riwayat /></PrivateRoute>}
        />
        <Route
          path="/admin/dashboard"
          element={<PrivateRoute><DashboardAdmin /></PrivateRoute>}
        />
        <Route
          path="/admin/rekap"
          element={<PrivateRoute><RekapAbsensi /></PrivateRoute>}
        />
      </Routes>
    </BrowserRouter>
  );
};

export default AppRoutes;
