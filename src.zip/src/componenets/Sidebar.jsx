import React from 'react';
import { Link, useLocation } from 'react-router-dom';

const Sidebar = ({ role }) => {
  const { pathname } = useLocation();

  const menuPegawai = [
    { to: '/pegawai/dashboard', label: 'Dashboard' },
    { to: '/pegawai/absen', label: 'Absen' },
    { to: '/pegawai/riwayat', label: 'Riwayat' },
  ];

  const menuAdmin = [
    { to: '/admin/dashboard', label: 'Dashboard' },
    { to: '/admin/rekap', label: 'Rekap' },
  ];

  const menu = role === 'admin' ? menuAdmin : menuPegawai;

  return (
    <div className="bg-white shadow-md w-48 h-screen px-4 py-6">
      <h2 className="text-lg font-semibold mb-6">Menu</h2>
      <ul className="space-y-2">
        {menu.map((item) => (
          <li key={item.to}>
            <Link
              to={item.to}
              className={`block px-3 py-2 rounded text-sm ${
                pathname === item.to
                  ? 'bg-blue-500 text-white'
                  : 'hover:bg-blue-100 text-gray-700'
              }`}
            >
              {item.label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Sidebar;
